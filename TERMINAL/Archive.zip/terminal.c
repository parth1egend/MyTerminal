#include "myhead.h"

void trimLeadingandTrailing(char *s)
{
    int i, j;

    for (i = 0; s[i] == ' ' || s[i] == '\t'; i++)
        ;

    for (j = 0; s[i]; i++)
    {
        s[j++] = s[i];
    }
    s[j] = '\0';
    for (i = 0; s[i] != '\0'; i++)
    {
        if (s[i] != ' ' && s[i] != '\t')
            j = i;
    }
    s[j + 1] = '\0';
}
char *removeBlanks(const char *str)
{
    int i, j;
    char *newString;

    newString = (char *)malloc(20);

    i = 0;
    j = 0;

    while (str[i] != '\0')
    {
        /* If blank space is found */
        if (str[i] == ' ')
        {
            newString[j] = ' ';
            j++;

            /* Skip all consecutive spaces */
            while (str[i] == ' ')
                i++;
        }

        newString[j] = str[i];

        i++;
        j++;
    }
    // NULL terminate the new string
    newString[j] = '\0';

    return newString;
}

int main()
{

    while (1)
    {

        char *prompt = (char *)malloc(sizeof(char) * 1000);
        char *hostname = (char *)malloc(sizeof(char) * 1000);
        char *pwd = (char *)malloc(sizeof(char) * 1000);
        // printf("\x1B[31m");
        getlogin_r(prompt, 1000);
        // printf("%s\n", prompt);
        // strcat(prompt,"\x1B[31m");
        //  strcat(prompt,"\033[0m");

        gethostname(hostname, 1000);
        // printf("%s\n", hostname);

        getcwd(pwd, 1000);
        // printf("%s\n", pwd);

        strcat(prompt, "\x1B[31m @ \033[0m");
        strcat(prompt, hostname);
        strcat(prompt, "\x1B[32m : \033[0m");
        // printf("\x1B[32m");
        strcat(prompt, pwd);
        strcat(prompt, "$");
        // printf("\033[0m");
        // printf("%s\n", prompt);
        // gcc terminal.c -lreadline -o a.out
        char *input = readline(prompt);
        if (strcmp(input, "") != 0)
            add_history(input);

        // char *exit="exit";
        // printf("%s", exit);
        //  if(strcmp(command,exit)==0)
        //  {
        //      break;
        //  }

        char command[1000];
        // printf("%c\n", command[500]);
        char *cd = command + 3;
        // char exit[1000];
        // char guidance[1000];

        strcpy(command, input);
        // strcpy(exit,input);
        // strcpy(guidance,input);
        trimLeadingandTrailing(command);
        removeBlanks(command);
        // printf("%s\n", command);
        // trimLeadingandTrailing(exit);
        // trimLeadingandTrailing(guidance);
        if (strcmp(command, "cd ~") == 0 || strcmp(command, "cd") == 0)
        {
            chdir("/Users/parthajit");
        }
        if (strcmp(command, "exit") == 0)
        {
            printf("Exiting the terminal...\n");
            break;
        }
        if (strcmp(command, "guidance") == 0)
        {
            printf("ls - The most frequently used command in Linux to list directories\n");
            printf("pwd - Print working directory command in Linux\n");
            printf("mkdir - Command used to create directories in Linux\n");
            printf("cat - Display file contents on the terminal\n");
            printf("man - Access manual pages for all Linux commands\n");
            printf("cd - change directory\n");
        }
        // if(strcmp(command,"cd ..")==0)
        // {
        //     chdir("..");
        // }
        // if(strcmp(command,"cd /")==0)
        // {
        //     chdir("/");
        // }
        int cmdcount = 0;
        if (command[0] == 'c' && command[1] == 'd')
        {
            chdir(cd);
            cmdcount = 1;
        }

        if (command[0] == 'm' && command[1] == 'y' && command[2] == 'l' && command[3] == 's')
        {
            myls(command, pwd);
            cmdcount = 1;
        }
        if (command[0] == 'm' && command[1] == 'y' && command[2] == 'c' && command[3] == 'p')
        {
            mycp(command, pwd);
            cmdcount = 1;
        }
        if (command[0] == 'm' && command[1] == 'y' && command[2] == 'm' && command[3] == 'v')
        {
            mymv(command, pwd);
            cmdcount = 1;
        }
        if (command[0] == 'm' && command[1] == 'y' && command[2] == 'p' && command[3] == 's')
        {
            myps(command, pwd);
            cmdcount = 1;
        }
        if (command[0] == 'm' && command[1] == 'y' && command[2] == 'g' && command[3] == 'r' && command[4] == 'e' && command[5] == 'p')
        {
            mygrep(command, pwd);
            cmdcount = 1;
        }
        if (cmdcount == 0)
            system(command);
        free(hostname);
        free(prompt);
        free(pwd);
    }

    return 0;
}
