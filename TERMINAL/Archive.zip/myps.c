#include "myhead.h"

int allnumbers(char *name)
{
    int k = 1;
    for (int i = 0; i < strlen(name); i++)
    {
        if (!isdigit(name[i]))
        {
            k = 0;
        }
    }
    return k;
}

struct data
{
    int pid;
    int ppid;
    int sid;
    char cmd[1000];
    unsigned long long int rss;
    long int sz;
    int uid;
    char username[256];
    int psr;
    char tty_name[256];
    long long int utime;
    long long int stime;
    time_t STIME;
    char formed_utime[256];
    char formed_STIME[256];
    int c;
};

int myps(char *command, char *pwd)
{
    if (command[4] != ' ')
    {
        printf("error : command not found \n");
        return 0;
    }
    int i = 0, n = 0, v = 0;
    char *newcommand = removeBlanks(command);
    char *cmdarray[100];

    int k = 0;
    cmdarray[k] = strtok(newcommand, " ");
    while (cmdarray[k] != NULL)
        cmdarray[++k] = strtok(NULL, " ");

    DIR *dir;
    struct dirent *dir_entry;

    dir = opendir("/proc");

    if (dir == NULL)
    {
        printf("Error opening /proc directory\n");
        return 0;
    }

    //  printf("PID\t\tTTY\t\tTIME\t\tCMD\n");

    while ((dir_entry = readdir(dir)) != NULL)
    {

        if (allnumbers(dir_entry->d_name))
        {
            struct data property;
            char address[1000];
            sprintf(address, "/proc/%s/stat", dir_entry->d_name);
            FILE *file = fopen(address, "r");
            fscanf(file, "%d %s %*c %d %*d %d %*d %*d %*u %*d %*d %*d %*d %lld %lld %*lld %*lld %*d %*d %*d %*d %ld %*d %*llu %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %d %d",
                   property.pid, property.cmd, property.ppid, property.sid, property.utime, property.stime, property.STIME, property.psr, property.c);
            property.c = property.stime / sysconf(_SC_CLK_TCK);
            fclose(file);
            sprintf(address, "/proc/%s/statm", dir_entry->d_name);
            file = fopen(address, "r");
            fscanf(file, "%ld %llu", property.sz, property.rss);
            property.rss *= 4;
            fclose(file);
            sprintf(address, "/proc/%s/status", dir_entry->d_name);
            file = fopen(address, "r");
            char line[256];
            while (fgets(line, sizeof(line), file))
            {
                if (sscanf(line, "Uid:\t%d", property.uid) == 1)
                {
                    break;
                }
            }
            fclose(file);
            struct passwd *pw = malloc(sizeof(struct passwd));
            pw = getpwuid(property.uid);
            strcpy(property.username, pw->pw_name);
            sprintf(address, "/proc/%s/fd/0", dir_entry->d_name);
            int fd = open(address, O_RDONLY, 0);
            if (ttyname(fd) != NULL)
                strcpy(property.tty_name, ttyname(fd));
            else
                strcpy(property.tty_name, "?");
            close(fd);

            time_t uptime;
            file = fopen("/proc/uptime", "r");
            fscanf(file, "%ld", &uptime);
            fclose(file);
            property.STIME = (uptime - (property.STIME) / sysconf(_SC_CLK_TCK));

            long long int PROG = (property.utime + property.stime) / sysconf(_SC_CLK_TCK);
            snprintf(property.formed_utime, 8, "%.02lld:%.02lld:%.02lld", (PROG / 3600) % 3600, (PROG / 60) % 60, PROG % 60);
            char new[1000];
            memset(new, '\0', 256);
            strcpy(new, property.cmd);
            for (int i = 1; i < strlen(property.cmd) - 1; i++)
            {
                property.cmd[i - 1] = new[i];
                property.cmd[i] = '\0';
            }
            if (property.tty_name[0] != '?')
            {
                memset(new, '\0', 256);
                strcpy(new, property.tty_name);
                for (int i = 5; i < strlen(new); i++)
                {
                    property.cmd[i - 5] = new[i];
                }
            }

            time_t now = time(0);
            property.STIME = now - property.STIME;
            struct tm *loop = localtime(&property.STIME);
            strftime(property.formed_STIME, 256, "%H:%M", loop);

            if (cmdarray[1][0] != '-')
            {
                printf("PID\t\tTTY\t\tTIME\t\tCMD\n");
                printf("%d\t\t%s\t\t%s\t\t%s\n", property.pid,property.tty_name,property.utime,property.cmd);
            }
        }
    }
}